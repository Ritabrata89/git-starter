### Application details

* This application reads the customer statement records(.csv & .xml files) from a directory.
* Then validates the data based on two rules.
* i> All transaction references should be unique.
* ii> The End Balance should be the total of Start Balance and Mutation.
* Then generates a final report(.csv file) containing all the records which fails the validation in the destination directory.

### How to run the project

1) Unzip the project.
2) Import as a maven project in IDE using pom.xml of the application
3) Update the *SOURCE_PATH* and *DESTINATION_PATH* in **ReportGenerator.java**
4) Run the **ReportGenerator.java**