package com.rabobank.reportgenerator;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * This is a utility class of the application which parses a xml file.
 * @author rtbrt2009@gmail.com
 */

public class ParseXML extends DefaultHandler {
    private StringBuilder currentValue = new StringBuilder();
    List<Records> recordsList;
    Records record;

    public List<Records> getResult() {
        return recordsList;
    }

    @Override
    public void startDocument() {
        recordsList = new ArrayList<>();
    }

    @Override
    public void startElement(
            String uri,
            String localName,
            String qName,
            Attributes attributes) {

        // reset the tag value
        currentValue.setLength(0);

        // start of loop
        if (qName.equalsIgnoreCase("record")) {

            record = new Records();

            // staff id
            String reference = attributes.getValue("reference");
            record.setReference(Integer.valueOf(reference));
        }
    }

    public void endElement(String uri,
                           String localName,
                           String qName) {

        if (qName.equalsIgnoreCase("accountNumber")) {
            record.setAccountNumber(currentValue.toString());
        }

        if (qName.equalsIgnoreCase("description")) {
            record.setDescription(currentValue.toString());
        }

        if (qName.equalsIgnoreCase("startBalance")) {
            record.setStartBalance(BigDecimal.valueOf(Double.valueOf(currentValue.toString())));
        }

        if (qName.equalsIgnoreCase("mutation")) {
            record.setMutation(BigDecimal.valueOf(Double.valueOf(currentValue.toString())));
        }

        if (qName.equalsIgnoreCase("endBalance")) {
            record.setEndBalance(BigDecimal.valueOf(Double.valueOf(currentValue.toString())));
        }

        if (qName.equalsIgnoreCase("record")) {
            recordsList.add(record);
        }

    }

    public void characters(char ch[], int start, int length) {
        currentValue.append(ch, start, length);

    }
}
