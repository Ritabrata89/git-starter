package com.rabobank.reportgenerator;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.math.BigDecimal;

/**
 * This is a model class of the application which contains the attributes of the records.
 * @author rtbrt2009@gmail.com
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@XmlRootElement
public class Records {
    @XmlAttribute
    private Integer reference;
    @XmlElement
    private String accountNumber;
    @XmlElement
    private String description;
    @XmlElement
    private BigDecimal startBalance;
    @XmlElement
    private BigDecimal mutation;
    @XmlElement
    private BigDecimal endBalance;
}
