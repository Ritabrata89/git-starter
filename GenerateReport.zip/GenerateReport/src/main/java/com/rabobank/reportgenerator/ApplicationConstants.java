package com.rabobank.reportgenerator;

/**This class defines all the constants used in this application
 *  * @author rtbrt2009@gmail.com
 * */

public class ApplicationConstants {
    //Source directory where the customer statement record are kept
    public static final String SOURCE_PATH =
            "/Users/rtbrt/Documents/Personal Docs/Java/RaboBank/GenerateReport/src/main/resources/";
    //Destination directory where the final report will be generated
    public static final String DESTINATION_PATH =
            "/Users/rtbrt/Documents/Personal Docs/Java/RaboBank/GenerateReport/src/main/resources/Reports/";
    //Header of final report
    public static final String[] REPORT_HEADER = { "Reference", "Description"};
}
