package com.rabobank.reportgenerator;

import java.io.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.opencsv.CSVWriter;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import static com.rabobank.reportgenerator.ApplicationConstants.*;

/**
 * This application reads the customer statement records(.csv & .xml files) from a directory.
 * Then validates the data based on two rules
 * i> All transaction references should be unique.
 * ii> The End Balance should be the total of Start Balance and Mutation.
 * Then generates a final report(.csv file) containing all the records which fails the validation
 * in the destination directory.
 * @author rtbrt2009@gmail.com
 */

public class ReportGenerator {

    public static void main(String[] args){
        File sourceDir = new File(SOURCE_PATH);
        File[] SourceFiles = sourceDir.listFiles();
        try{
            CSVWriter writer = new CSVWriter(new FileWriter(DESTINATION_PATH+"Report"+LocalDateTime.now()
                    .format(DateTimeFormatter.ofPattern("yyyy.MM.dd_hh.mm.ss"))+".csv"));
            writer.writeNext(REPORT_HEADER);
            for (File file : SourceFiles) {
                if(file.getName().contains(".csv")){
                    System.out.println("Parsing CSV");
                    List<Records> duplicateData = processRecord(csvParser(new FileInputStream(file)));
                    if(!duplicateData.isEmpty())
                        writeToReport(duplicateData, writer);
                }else if(file.getName().contains(".xml")){
                    System.out.println("Parsing XML");
                    List<Records> duplicateData = processRecord(xmlParser(file));
                    if(!duplicateData.isEmpty())
                        writeToReport(duplicateData, writer);
                }else{
                    System.out.println("Invalid file "+file.getName());
                }
            }
            writer.close();
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**This method parses the csv file
     * @param is
     * */
    public static List<Records> csvParser(InputStream is) throws Exception {
        try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
             CSVParser csvParser = new CSVParser(fileReader,
                     CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());){

            List<Records> records = new ArrayList<Records>();
            Iterable<CSVRecord> csvRecords = csvParser.getRecords();
            for (CSVRecord csvRecord : csvRecords) {
                Records record = new Records(
                        Integer.valueOf(csvRecord.get(0)),
                        csvRecord.get(1), csvRecord.get(2),
                        BigDecimal.valueOf(Double.valueOf(csvRecord.get(3))),
                        BigDecimal.valueOf(Double.valueOf(csvRecord.get(4))),
                        BigDecimal.valueOf(Double.valueOf(csvRecord.get(5))));
                records.add(record);}
            return records;
        }catch (IOException e) {
            throw new Exception();
        }
    }

    /**This method parses the xml file
     * @param sourceFile
     * */
    public static List<Records> xmlParser(File sourceFile) throws IOException, ParserConfigurationException, SAXException {
        List<Records> records;
        SAXParserFactory factory = SAXParserFactory.newInstance();
        InputStream is = new FileInputStream(sourceFile);
            SAXParser saxParser = factory.newSAXParser();
            ParseXML handler = new ParseXML();
            saxParser.parse(is, handler);
            records = handler.getResult();
        return records;
    }

    /**This method processes and validates the records
     * @param records
     * */
    public static List<Records> processRecord(List<Records> records) {
        HashMap<Integer, Records> map
                = new HashMap<Integer, Records>();
        List<Records> duplicate = new ArrayList<Records>();
        for(Records record : records){
            if((record.getStartBalance().add(record.getMutation())).compareTo(record.getEndBalance())==0){
                if(!map.containsKey(record.getReference()))
                    map.put(record.getReference(), record);
                else
                    duplicate.add(record);
            }else{
                duplicate.add(record);
            }
        }
        //writeToReport(duplicate);
        return duplicate;
    }

    /**This method writes to the report.
     * @param records and writer
     * */
    public static void writeToReport(List<Records> records, CSVWriter writer) {
        List<String[]> recordArr = new ArrayList<String[]>();
        for(Records record : records){
            String[] row = {String.valueOf(record.getReference()), record.getDescription()};
            recordArr.add(row);
        }
        writer.writeAll(recordArr);
    }
}
