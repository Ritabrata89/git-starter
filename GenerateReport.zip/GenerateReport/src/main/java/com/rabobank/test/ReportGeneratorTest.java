package com.rabobank.test;

import com.rabobank.reportgenerator.Records;
import com.rabobank.reportgenerator.ReportGenerator;
import org.junit.Test;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * This is a test class of the application.
 * @author rtbrt2009@gmail.com
 */

import static com.rabobank.reportgenerator.ApplicationConstants.SOURCE_PATH;
import static org.junit.Assert.assertEquals;

public class ReportGeneratorTest {
    //Source directory where the customer statement record are kept
    private static final String CSV_PATH = SOURCE_PATH+"records.csv";
    private static final String XML_PATH = SOURCE_PATH+"records.xml";

    @Test
    public void csvParserTest() throws Exception {
        File csv = new File(CSV_PATH);
        List<Records> records = ReportGenerator.csvParser(new FileInputStream(csv));
        assertEquals(false, records.isEmpty());
    }

    @Test
    public void xmlParserTest() throws Exception {
        File xml = new File(XML_PATH);
        List<Records> records = ReportGenerator.xmlParser(xml);
        assertEquals(false, records.isEmpty());
    }

    @Test
    public void processRecordTest() {
        List<Records> duplicate = ReportGenerator.processRecord(getRecordsList());
        assertEquals(false, duplicate.isEmpty());
    }

    public List<Records> getRecordsList(){
        Records record1 = new Records();
        record1.setReference(12345);
        record1.setStartBalance(BigDecimal.valueOf(25.5));
        record1.setMutation(BigDecimal.valueOf(1.5));
        record1.setEndBalance(BigDecimal.valueOf(27));
        record1.setDescription("For test case");

        Records record2 = new Records();
        record2.setReference(12345);
        record2.setStartBalance(BigDecimal.valueOf(25.5));
        record2.setMutation(BigDecimal.valueOf(1.5));
        record2.setEndBalance(BigDecimal.valueOf(27));
        record2.setDescription("For test case");

        Records record3 = new Records();
        record3.setReference(12347);
        record3.setStartBalance(BigDecimal.valueOf(25.5));
        record3.setMutation(BigDecimal.valueOf(-1.5));
        record3.setEndBalance(BigDecimal.valueOf(27));
        record3.setDescription("For test case");

        List<Records> records = new ArrayList<>();
        records.add(record1);
        records.add(record2);
        records.add(record3);

        return records;
    }
}
